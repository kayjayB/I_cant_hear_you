//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: timeDelay_initialize.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 01-Aug-2018 12:42:33
//
#ifndef TIMEDELAY_INITIALIZE_H
#define TIMEDELAY_INITIALIZE_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "timeDelay_types.h"

// Function Declarations
extern void timeDelay_initialize();

#endif

//
// File trailer for timeDelay_initialize.h
//
// [EOF]
//
