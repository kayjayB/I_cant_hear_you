//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: timeDelay.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 10-Aug-2018 10:10:20
//
#ifndef TIMEDELAY_H
#define TIMEDELAY_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "rangeCompression_types.h"

// Function Declarations
extern void timeDelay(const double bandInput_data[], const int bandInput_size[2],
                      const double weightTableTimeDelay_data[], const int
                      weightTableTimeDelay_size[2], double Fs, double
                      bandOutput_data[], int bandOutput_size[2]);

#endif

//
// File trailer for timeDelay.h
//
// [EOF]
//
