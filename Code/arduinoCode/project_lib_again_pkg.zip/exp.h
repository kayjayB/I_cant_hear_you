//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: exp.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 14-Aug-2018 11:58:16
//
#ifndef EXP_H
#define EXP_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "rangeCompression_types.h"

// Function Declarations
extern void b_exp(creal_T x_data[], int x_size[1]);

#endif

//
// File trailer for exp.h
//
// [EOF]
//
