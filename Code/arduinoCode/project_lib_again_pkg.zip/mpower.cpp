//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: mpower.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 14-Aug-2018 11:58:16
//

// Include Files
#include "rt_nonfinite.h"
#include "rangeCompression.h"
#include "timeDelay.h"
#include "mpower.h"
#include "CompressorBase.h"
#include "rangeCompression_rtwutil.h"

// Function Definitions

//
// Arguments    : double b
// Return Type  : double
//
double mpower(double b)
{
  return rt_powd_snf(2.0, b);
}

//
// File trailer for mpower.cpp
//
// [EOF]
//
