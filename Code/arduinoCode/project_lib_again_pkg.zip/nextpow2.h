//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: nextpow2.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 14-Aug-2018 11:58:16
//
#ifndef NEXTPOW2_H
#define NEXTPOW2_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "rangeCompression_types.h"

// Function Declarations
extern double nextpow2(double n);

#endif

//
// File trailer for nextpow2.h
//
// [EOF]
//
