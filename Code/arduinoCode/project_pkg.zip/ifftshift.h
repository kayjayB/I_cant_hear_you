//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: ifftshift.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 06-Aug-2018 14:10:06
//
#ifndef IFFTSHIFT_H
#define IFFTSHIFT_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "rangeCompression_types.h"

// Function Declarations
extern void ifftshift(double x_data[], int x_size[1]);

#endif

//
// File trailer for ifftshift.h
//
// [EOF]
//
