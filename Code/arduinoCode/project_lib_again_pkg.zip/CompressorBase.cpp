//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: CompressorBase.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 14-Aug-2018 11:58:16
//

// Include Files
#include <string.h>
#include <cmath>
#include "rt_nonfinite.h"
#include "rangeCompression.h"
#include "timeDelay.h"
#include "CompressorBase.h"
#include "compressor.h"
#include "abs.h"
#include "rangeCompression_rtwutil.h"

// Function Declarations
static void CompressorBase_detectLevel(compressor *obj, const double x[100],
  double yout[100]);

// Function Definitions

//
// Arguments    : compressor *obj
//                const double x[100]
//                double yout[100]
// Return Type  : void
//
static void CompressorBase_detectLevel(compressor *obj, const double x[100],
  double yout[100])
{
  double y[101];
  double alphaA;
  double alphaR;
  int i;
  memset(&y[0], 0, 101U * sizeof(double));
  y[0] = obj->pLevelDetectionState;
  alphaA = obj->pAlphaA;
  alphaR = obj->pAlphaR;
  for (i = 0; i < 100; i++) {
    if (x[i] <= y[i]) {
      y[i + 1] = alphaA * y[i] + (1.0 - alphaA) * x[i];
    } else {
      y[i + 1] = alphaR * y[i] + (1.0 - alphaR) * x[i];
    }

    yout[i] = y[i + 1];
  }

  obj->pLevelDetectionState = y[100];
}

//
// Arguments    : compressor *obj
//                const double x[100]
//                double y[100]
// Return Type  : void
//
void CompressorBase_stepImpl(compressor *obj, const double x[100], double y[100])
{
  double G[100];
  int k;
  double b_G[100];
  double u0;
  b_abs(x, G);
  for (k = 0; k < 100; k++) {
    u0 = G[k];
    if (!(u0 > 2.2204460492503131E-16)) {
      u0 = 2.2204460492503131E-16;
    }

    b_G[k] = 20.0 * std::log10(u0);
  }

  compressor_computeGain(obj, b_G, G);
  memcpy(&b_G[0], &G[0], 100U * sizeof(double));
  CompressorBase_detectLevel(obj, b_G, G);
  for (k = 0; k < 100; k++) {
    y[k] = x[k] * rt_powd_snf(10.0, (G[k] + obj->pMakeUpGain) / 20.0);
  }
}

//
// File trailer for CompressorBase.cpp
//
// [EOF]
//
