//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: rangeCompression_initialize.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 10-Aug-2018 10:10:20
//
#ifndef RANGECOMPRESSION_INITIALIZE_H
#define RANGECOMPRESSION_INITIALIZE_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "rangeCompression_types.h"

// Function Declarations
extern void rangeCompression_initialize();

#endif

//
// File trailer for rangeCompression_initialize.h
//
// [EOF]
//
