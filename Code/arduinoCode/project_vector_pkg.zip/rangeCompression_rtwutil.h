//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: rangeCompression_rtwutil.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 10-Aug-2018 10:10:20
//
#ifndef RANGECOMPRESSION_RTWUTIL_H
#define RANGECOMPRESSION_RTWUTIL_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "rangeCompression_types.h"

// Function Declarations
extern double rt_powd_snf(double u0, double u1);

#endif

//
// File trailer for rangeCompression_rtwutil.h
//
// [EOF]
//
