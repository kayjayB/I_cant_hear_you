//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: timeDelay.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 14-Aug-2018 11:58:16
//
#ifndef TIMEDELAY_H
#define TIMEDELAY_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "rangeCompression_types.h"

// Function Declarations
extern void timeDelay(const double bandInput[800], const double
                      weightTableTimeDelay[8], double Fs, double bandOutput[800]);

#endif

//
// File trailer for timeDelay.h
//
// [EOF]
//
