//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: rangeCompression.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 14-Aug-2018 11:58:16
//

// Include Files
#include <cmath>
#include "rt_nonfinite.h"
#include "rangeCompression.h"
#include "timeDelay.h"
#include "CompressorBase.h"

// Function Definitions

//
// Arguments    : const double buffer[100]
//                double Fs
//                double output[100]
// Return Type  : void
//
void rangeCompression(const double buffer[100], double Fs, double output[100])
{
  compressor dRC;
  dRC.KneeWidth = 0.0;
  dRC.Ratio = 5.0;
  dRC.Threshold = -10.0;
  dRC.MakeUpGain = 0.0;
  dRC.pSampleRateDialog = Fs;
  dRC.AttackTime = 0.1;
  dRC.ReleaseTime = 0.2;
  dRC.matlabCodegenIsDeleted = false;
  dRC.isInitialized = 1;
  dRC.pNumChannels = 1.0;
  dRC.pMakeUpGain = 0.0;
  dRC.isSetupComplete = true;
  dRC.TunablePropsChanged = false;
  dRC.pLevelDetectionState = 0.0;
  dRC.pAlphaA = std::exp(-2.1972245773362196 / (0.1 * Fs));
  dRC.pAlphaR = std::exp(-2.1972245773362196 / (0.2 * Fs));
  CompressorBase_stepImpl(&dRC, buffer, output);
}

//
// File trailer for rangeCompression.cpp
//
// [EOF]
//
