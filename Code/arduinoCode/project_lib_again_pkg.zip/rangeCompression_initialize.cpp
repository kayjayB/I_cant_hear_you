//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: rangeCompression_initialize.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 14-Aug-2018 11:58:16
//

// Include Files
#include "rt_nonfinite.h"
#include "rangeCompression.h"
#include "timeDelay.h"
#include "rangeCompression_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void rangeCompression_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for rangeCompression_initialize.cpp
//
// [EOF]
//
