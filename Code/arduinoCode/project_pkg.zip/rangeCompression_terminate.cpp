//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: rangeCompression_terminate.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 06-Aug-2018 14:10:06
//

// Include Files
#include "rt_nonfinite.h"
#include "rangeCompression.h"
#include "timeDelay.h"
#include "rangeCompression_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void rangeCompression_terminate()
{
  // (no terminate code required)
}

//
// File trailer for rangeCompression_terminate.cpp
//
// [EOF]
//
