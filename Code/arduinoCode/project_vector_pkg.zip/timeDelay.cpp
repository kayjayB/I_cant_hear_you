//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: timeDelay.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 10-Aug-2018 10:10:20
//

// Include Files
#include <math.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rangeCompression.h"
#include "timeDelay.h"
#include "ifft.h"
#include "exp.h"
#include "ifftshift.h"
#include "fft.h"
#include "mpower.h"
#include "nextpow2.h"
#include "round.h"

// Function Definitions

//
// Arguments    : const double bandInput_data[]
//                const int bandInput_size[2]
//                const double weightTableTimeDelay_data[]
//                const int weightTableTimeDelay_size[2]
//                double Fs
//                double bandOutput_data[]
//                int bandOutput_size[2]
// Return Type  : void
//
void timeDelay(const double bandInput_data[], const int bandInput_size[2], const
               double weightTableTimeDelay_data[], const int
               weightTableTimeDelay_size[2], double Fs, double bandOutput_data[],
               int bandOutput_size[2])
{
  int dt_size_idx_1;
  int loop_ub;
  int i0;
  boolean_T bSingleVecX;
  double dt_data[8];
  int delayInt_size[2];
  double orgStart;
  double delayInt_data[8];
  double delayFrac_data[8];
  int idx;
  int k;
  boolean_T exitg1;
  double maxLengthLimit;
  double output_data[800];
  int colI;
  int tmpx_size[1];
  double tmpx_data[400];
  double d0;
  double newStart;
  double y_data[128];
  creal_T tmpxd_data[128];
  int tmpxd_size[1];
  double y_re;
  double y_im;
  int tmp_size[1];
  double tmp_data[128];
  int b_tmp_size[1];
  creal_T b_tmp_data[128];
  int b_tmpxd_size[1];
  creal_T b_tmpxd_data[128];
  dt_size_idx_1 = weightTableTimeDelay_size[1];
  loop_ub = weightTableTimeDelay_size[0] * weightTableTimeDelay_size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    dt_data[i0] = weightTableTimeDelay_data[i0] * Fs;
  }

  bSingleVecX = true;
  if (bandInput_size[1] != 1) {
    bSingleVecX = false;
    if (weightTableTimeDelay_size[1] == 1) {
      orgStart = 0.0;
      for (i0 = 0; i0 < dt_size_idx_1; i0++) {
        orgStart += dt_data[i0];
      }

      dt_size_idx_1 = 1;
      dt_data[0] = orgStart;
    }
  }

  delayInt_size[0] = 1;
  delayInt_size[1] = dt_size_idx_1;
  if (0 <= dt_size_idx_1 - 1) {
    memcpy(&delayInt_data[0], &dt_data[0], (unsigned int)(dt_size_idx_1 * (int)
            sizeof(double)));
  }

  b_round(delayInt_data, delayInt_size);
  for (i0 = 0; i0 < dt_size_idx_1; i0++) {
    delayFrac_data[i0] = dt_data[i0] - delayInt_data[i0];
  }

  if (delayInt_size[1] <= 2) {
    if (delayInt_size[1] == 1) {
      orgStart = delayInt_data[0];
    } else if ((delayInt_data[0] < delayInt_data[1]) || (rtIsNaN(delayInt_data[0])
                && (!rtIsNaN(delayInt_data[1])))) {
      orgStart = delayInt_data[1];
    } else {
      orgStart = delayInt_data[0];
    }
  } else {
    if (!rtIsNaN(delayInt_data[0])) {
      idx = 1;
    } else {
      idx = 0;
      k = 2;
      exitg1 = false;
      while ((!exitg1) && (k <= delayInt_size[1])) {
        if (!rtIsNaN(delayInt_data[k - 1])) {
          idx = k;
          exitg1 = true;
        } else {
          k++;
        }
      }
    }

    if (idx == 0) {
      orgStart = delayInt_data[0];
    } else {
      orgStart = delayInt_data[idx - 1];
      while (idx + 1 <= delayInt_size[1]) {
        if (orgStart < delayInt_data[idx]) {
          orgStart = delayInt_data[idx];
        }

        idx++;
      }
    }
  }

  if ((0.0 > orgStart) || rtIsNaN(orgStart)) {
    orgStart = 0.0;
  }

  if (50.0 + orgStart > 100.0) {
    maxLengthLimit = 100.0;
  } else {
    maxLengthLimit = 50.0 + orgStart;
  }

  loop_ub = (int)maxLengthLimit * dt_size_idx_1;
  if (0 <= loop_ub - 1) {
    memset(&output_data[0], 0, (unsigned int)(loop_ub * (int)sizeof(double)));
  }

  for (colI = 0; colI < dt_size_idx_1; colI++) {
    if ((50.0 + delayInt_data[colI] <= 0.0) || (50.0 + delayInt_data[colI] >
         100.0)) {
    } else {
      if (bSingleVecX) {
        tmpx_size[0] = 50 * bandInput_size[1];
        loop_ub = 50 * bandInput_size[1];
        if (0 <= loop_ub - 1) {
          memcpy(&tmpx_data[0], &bandInput_data[0], (unsigned int)(loop_ub *
                  (int)sizeof(double)));
        }
      } else {
        tmpx_size[0] = 50;
        memcpy(&tmpx_data[0], &bandInput_data[bandInput_size[0] * colI], 50U *
               sizeof(double));
      }

      if (delayFrac_data[colI] != 0.0) {
        if ((0.0 > delayInt_data[colI]) || rtIsNaN(delayInt_data[colI])) {
          d0 = 0.0;
        } else {
          d0 = delayInt_data[colI];
        }

        orgStart = mpower(nextpow2(50.0 + d0));
        newStart = floor(orgStart / 2.0);
        if (rtIsNaN(orgStart - 1.0)) {
          idx = 1;
          y_data[0] = rtNaN;
        } else if (orgStart - 1.0 < 0.0) {
          idx = 0;
        } else if (rtIsInf(orgStart - 1.0) && (0.0 == orgStart - 1.0)) {
          idx = 1;
          y_data[0] = rtNaN;
        } else {
          idx = (int)floor(orgStart - 1.0) + 1;
          loop_ub = (int)floor(orgStart - 1.0);
          for (i0 = 0; i0 <= loop_ub; i0++) {
            y_data[i0] = i0;
          }
        }

        if ((tmpx_size[0] == 1) && (orgStart == 1.0)) {
          for (i0 = 0; i0 < 1; i0++) {
            tmpxd_data[0].re = tmpx_data[0];
            tmpxd_data[0].im = 0.0;
          }
        } else {
          fft(tmpx_data, tmpx_size, orgStart, tmpxd_data, tmpxd_size);
          y_re = dt_data[colI] * 0.0;
          y_im = -dt_data[colI];
          tmp_size[0] = idx;
          for (i0 = 0; i0 < idx; i0++) {
            tmp_data[i0] = y_data[i0] - newStart;
          }

          ifftshift(tmp_data, tmp_size);
          b_tmp_size[0] = tmp_size[0];
          loop_ub = tmp_size[0];
          for (i0 = 0; i0 < loop_ub; i0++) {
            b_tmp_data[i0].re = 6.2831853071795862 * tmp_data[i0] / orgStart *
              y_re;
            b_tmp_data[i0].im = 6.2831853071795862 * tmp_data[i0] / orgStart *
              y_im;
          }

          b_exp(b_tmp_data, b_tmp_size);
          b_tmpxd_size[0] = tmpxd_size[0];
          loop_ub = tmpxd_size[0];
          for (i0 = 0; i0 < loop_ub; i0++) {
            b_tmpxd_data[i0].re = tmpxd_data[i0].re * b_tmp_data[i0].re -
              tmpxd_data[i0].im * b_tmp_data[i0].im;
            b_tmpxd_data[i0].im = tmpxd_data[i0].re * b_tmp_data[i0].im +
              tmpxd_data[i0].im * b_tmp_data[i0].re;
          }

          ifft(b_tmpxd_data, b_tmpxd_size, tmpxd_data, tmpxd_size);
        }

        if (delayInt_data[colI] >= 0.0) {
          orgStart = delayInt_data[colI] + 1.0;
          newStart = delayInt_data[colI] + 1.0;
        } else {
          orgStart = 1.0;
          newStart = 1.0;
        }

        if (orgStart > 50.0 + delayInt_data[colI]) {
          i0 = 1;
          idx = 0;
        } else {
          i0 = (int)orgStart;
          idx = (int)(50.0 + delayInt_data[colI]);
        }

        if (newStart > 50.0 + delayInt_data[colI]) {
          k = 0;
        } else {
          k = (int)newStart - 1;
        }

        loop_ub = idx - i0;
        for (idx = 0; idx <= loop_ub; idx++) {
          output_data[(k + idx) + (int)maxLengthLimit * colI] = tmpxd_data[(i0 +
            idx) - 1].re;
        }
      } else {
        if (delayInt_data[colI] >= 0.0) {
          orgStart = 1.0;
          newStart = delayInt_data[colI] + 1.0;
        } else {
          orgStart = 1.0 - delayInt_data[colI];
          newStart = 1.0;
        }

        if (orgStart > 50.0) {
          i0 = 1;
          idx = 0;
        } else {
          i0 = (int)orgStart;
          idx = 50;
        }

        if (newStart > 50.0 + delayInt_data[colI]) {
          k = 0;
        } else {
          k = (int)newStart - 1;
        }

        loop_ub = idx - i0;
        for (idx = 0; idx <= loop_ub; idx++) {
          output_data[(k + idx) + (int)maxLengthLimit * colI] = tmpx_data[(i0 +
            idx) - 1];
        }
      }
    }
  }

  bandOutput_size[0] = 50;
  bandOutput_size[1] = dt_size_idx_1;
  for (i0 = 0; i0 < dt_size_idx_1; i0++) {
    for (idx = 0; idx < 50; idx++) {
      bandOutput_data[idx + 50 * i0] = output_data[idx + (int)maxLengthLimit *
        i0];
    }
  }
}

//
// File trailer for timeDelay.cpp
//
// [EOF]
//
