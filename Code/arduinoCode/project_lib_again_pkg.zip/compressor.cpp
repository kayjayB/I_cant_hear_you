//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: compressor.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 14-Aug-2018 11:58:16
//

// Include Files
#include <cmath>
#include "rt_nonfinite.h"
#include "rangeCompression.h"
#include "timeDelay.h"
#include "compressor.h"
#include "power.h"

// Function Definitions

//
// Arguments    : const compressor *obj
//                const double xG[100]
//                double G[100]
// Return Type  : void
//
void compressor_computeGain(const compressor *obj, const double xG[100], double
  G[100])
{
  double W;
  double R;
  double T;
  int trueCount;
  int i;
  int partialTrueCount;
  boolean_T ind2;
  boolean_T b_ind2[100];
  signed char tmp_data[100];
  double y_data[256];
  double y;
  double a;
  signed char b_tmp_data[100];
  int xG_size[1];
  double xG_data[100];
  double c_tmp_data[100];
  int tmp_size[1];
  W = obj->KneeWidth;
  R = obj->Ratio;
  T = obj->Threshold;
  trueCount = 0;
  for (i = 0; i < 100; i++) {
    G[i] = xG[i];
    ind2 = (2.0 * (xG[i] - T) > W);
    if (ind2) {
      trueCount++;
    }

    b_ind2[i] = ind2;
  }

  partialTrueCount = 0;
  for (i = 0; i < 100; i++) {
    if (b_ind2[i]) {
      tmp_data[partialTrueCount] = (signed char)(i + 1);
      partialTrueCount++;
    }
  }

  for (partialTrueCount = 0; partialTrueCount < trueCount; partialTrueCount++) {
    y_data[partialTrueCount] = (xG[tmp_data[partialTrueCount] - 1] - T) / R;
  }

  partialTrueCount = 0;
  for (i = 0; i < 100; i++) {
    if (b_ind2[i]) {
      G[i] = T + y_data[partialTrueCount];
      partialTrueCount++;
    }
  }

  if (W != 0.0) {
    trueCount = 0;
    for (i = 0; i < 100; i++) {
      ind2 = (2.0 * std::abs(xG[i] - T) <= W);
      if (ind2) {
        trueCount++;
      }

      b_ind2[i] = ind2;
    }

    partialTrueCount = 0;
    for (i = 0; i < 100; i++) {
      if (b_ind2[i]) {
        b_tmp_data[partialTrueCount] = (signed char)(i + 1);
        partialTrueCount++;
      }
    }

    y = W / 2.0;
    a = 1.0 / R - 1.0;
    R = 2.0 * W;
    xG_size[0] = trueCount;
    for (partialTrueCount = 0; partialTrueCount < trueCount; partialTrueCount++)
    {
      xG_data[partialTrueCount] = (xG[b_tmp_data[partialTrueCount] - 1] - T) + y;
    }

    power(xG_data, xG_size, c_tmp_data, tmp_size);
    i = tmp_size[0];
    for (partialTrueCount = 0; partialTrueCount < i; partialTrueCount++) {
      y_data[partialTrueCount] = a * c_tmp_data[partialTrueCount] / R;
    }

    partialTrueCount = 0;
    for (i = 0; i < 100; i++) {
      if (b_ind2[i]) {
        G[i] = xG[i] + y_data[partialTrueCount];
        partialTrueCount++;
      }
    }
  }

  for (partialTrueCount = 0; partialTrueCount < 100; partialTrueCount++) {
    G[partialTrueCount] -= xG[partialTrueCount];
  }
}

//
// File trailer for compressor.cpp
//
// [EOF]
//
