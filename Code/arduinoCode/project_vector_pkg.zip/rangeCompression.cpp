//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: rangeCompression.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 10-Aug-2018 10:10:20
//

// Include Files
#include <math.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rangeCompression.h"
#include "timeDelay.h"
#include "compressor.h"
#include "rangeCompression_rtwutil.h"

// Function Definitions

//
// Arguments    : const double buffer[50]
//                double Fs
//                double output[50]
// Return Type  : void
//
void rangeCompression(const double buffer[50], double Fs, double output[50])
{
  compressor dRC;
  int k;
  double dv0[50];
  double G[50];
  double alphaA;
  double y[51];
  double alphaR;
  dRC.KneeWidth = 0.0;
  dRC.Ratio = 5.0;
  dRC.Threshold = -10.0;
  dRC.MakeUpGain = 0.0;
  dRC.pSampleRateDialog = Fs;
  dRC.AttackTime = 0.1;
  dRC.ReleaseTime = 0.2;
  dRC.matlabCodegenIsDeleted = false;
  dRC.isInitialized = 1;
  dRC.pNumChannels = 1.0;
  dRC.pMakeUpGain = 0.0;
  dRC.isSetupComplete = true;
  dRC.TunablePropsChanged = false;
  dRC.pLevelDetectionState = 0.0;
  dRC.pAlphaA = exp(-2.1972245773362196 / (0.1 * Fs));
  dRC.pAlphaR = exp(-2.1972245773362196 / (0.2 * Fs));
  for (k = 0; k < 50; k++) {
    alphaA = fabs(buffer[k]);
    if (!(alphaA > 2.2204460492503131E-16)) {
      alphaA = 2.2204460492503131E-16;
    }

    dv0[k] = 20.0 * log10(alphaA);
  }

  compressor_computeGain(&dRC, dv0, G);
  memset(&y[0], 0, 51U * sizeof(double));
  y[0] = 0.0;
  alphaA = dRC.pAlphaA;
  alphaR = dRC.pAlphaR;
  for (k = 0; k < 50; k++) {
    if (G[k] <= y[k]) {
      y[k + 1] = alphaA * y[k] + (1.0 - alphaA) * G[k];
    } else {
      y[k + 1] = alphaR * y[k] + (1.0 - alphaR) * G[k];
    }

    output[k] = buffer[k] * rt_powd_snf(10.0, y[k + 1] / 20.0);
  }
}

//
// File trailer for rangeCompression.cpp
//
// [EOF]
//
