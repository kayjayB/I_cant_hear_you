//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: rangeCompression_types.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 14-Aug-2018 11:58:16
//
#ifndef RANGECOMPRESSION_TYPES_H
#define RANGECOMPRESSION_TYPES_H

// Include Files
#include "rtwtypes.h"

// Type Definitions
typedef struct {
  unsigned int f1[8];
} cell_wrap_3;

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int isInitialized;
  boolean_T isSetupComplete;
  boolean_T TunablePropsChanged;
  cell_wrap_3 inputVarSize[1];
  double pSampleRateDialog;
  double Threshold;
  double AttackTime;
  double ReleaseTime;
  double pNumChannels;
  double pAlphaA;
  double pAlphaR;
  double pLevelDetectionState;
  double MakeUpGain;
  double KneeWidth;
  double pMakeUpGain;
  double Ratio;
} compressor;

#endif

//
// File trailer for rangeCompression_types.h
//
// [EOF]
//
