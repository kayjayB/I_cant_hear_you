//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: abs.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 14-Aug-2018 11:58:16
//

// Include Files
#include <cmath>
#include "rt_nonfinite.h"
#include "rangeCompression.h"
#include "timeDelay.h"
#include "abs.h"

// Function Definitions

//
// Arguments    : const double x[100]
//                double y[100]
// Return Type  : void
//
void b_abs(const double x[100], double y[100])
{
  int k;
  for (k = 0; k < 100; k++) {
    y[k] = std::abs(x[k]);
  }
}

//
// File trailer for abs.cpp
//
// [EOF]
//
