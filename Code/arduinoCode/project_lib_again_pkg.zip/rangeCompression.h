//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: rangeCompression.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 14-Aug-2018 11:58:16
//
#ifndef RANGECOMPRESSION_H
#define RANGECOMPRESSION_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "rangeCompression_types.h"

// Function Declarations
extern void rangeCompression(const double buffer[100], double Fs, double output
  [100]);

#endif

//
// File trailer for rangeCompression.h
//
// [EOF]
//
