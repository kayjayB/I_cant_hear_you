//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: compressor.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 10-Aug-2018 10:10:20
//
#ifndef COMPRESSOR_H
#define COMPRESSOR_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "rangeCompression_types.h"

// Function Declarations
extern void compressor_computeGain(const compressor *obj, const double xG[50],
  double G[50]);

#endif

//
// File trailer for compressor.h
//
// [EOF]
//
