//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: rangeCompression_terminate.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 10-Aug-2018 10:10:20
//
#ifndef RANGECOMPRESSION_TERMINATE_H
#define RANGECOMPRESSION_TERMINATE_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "rangeCompression_types.h"

// Function Declarations
extern void rangeCompression_terminate();

#endif

//
// File trailer for rangeCompression_terminate.h
//
// [EOF]
//
