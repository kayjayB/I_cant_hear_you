//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: nextpow2.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 10-Aug-2018 10:10:20
//

// Include Files
#include <math.h>
#include "rt_nonfinite.h"
#include "rangeCompression.h"
#include "timeDelay.h"
#include "nextpow2.h"

// Function Definitions

//
// Arguments    : double n
// Return Type  : double
//
double nextpow2(double n)
{
  double p;
  double f;
  int eint;
  p = fabs(n);
  if ((!rtIsInf(p)) && (!rtIsNaN(p))) {
    f = frexp(p, &eint);
    p = eint;
    if (f == 0.5) {
      p = (double)eint - 1.0;
    }
  }

  return p;
}

//
// File trailer for nextpow2.cpp
//
// [EOF]
//
