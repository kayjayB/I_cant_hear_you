//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: power.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 14-Aug-2018 11:58:16
//
#ifndef POWER_H
#define POWER_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "rangeCompression_types.h"

// Function Declarations
extern void power(const double a_data[], const int a_size[1], double y_data[],
                  int y_size[1]);

#endif

//
// File trailer for power.h
//
// [EOF]
//
