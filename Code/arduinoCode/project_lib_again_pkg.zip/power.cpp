//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: power.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 14-Aug-2018 11:58:16
//

// Include Files
#include "rt_nonfinite.h"
#include "rangeCompression.h"
#include "timeDelay.h"
#include "power.h"

// Function Definitions

//
// Arguments    : const double a_data[]
//                const int a_size[1]
//                double y_data[]
//                int y_size[1]
// Return Type  : void
//
void power(const double a_data[], const int a_size[1], double y_data[], int
           y_size[1])
{
  int k;
  y_size[0] = (signed char)a_size[0];
  for (k = 0; k < (signed char)a_size[0]; k++) {
    y_data[k] = a_data[k] * a_data[k];
  }
}

//
// File trailer for power.cpp
//
// [EOF]
//
