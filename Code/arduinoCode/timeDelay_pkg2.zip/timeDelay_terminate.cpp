//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: timeDelay_terminate.cpp
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 01-Aug-2018 12:42:33
//

// Include Files
#include "rt_nonfinite.h"
#include "timeDelay.h"
#include "timeDelay_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void timeDelay_terminate()
{
  // (no terminate code required)
}

//
// File trailer for timeDelay_terminate.cpp
//
// [EOF]
//
