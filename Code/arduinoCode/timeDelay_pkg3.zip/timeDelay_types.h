//
// Trial License - for use to evaluate programs for possible purchase as
// an end-user only.
// File: timeDelay_types.h
//
// MATLAB Coder version            : 4.0
// C/C++ source code generated on  : 01-Aug-2018 16:22:00
//
#ifndef TIMEDELAY_TYPES_H
#define TIMEDELAY_TYPES_H

// Include Files
#include "rtwtypes.h"
#endif

//
// File trailer for timeDelay_types.h
//
// [EOF]
//
